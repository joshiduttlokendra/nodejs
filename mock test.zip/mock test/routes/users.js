const express = require("express");
const router = express.Router();
const { ensureAuthenticated } = require("../configure/auth");
const db = require("../configure/config");

router.get("/admin", ensureAuthenticated, (req, res) => {
  res.render("admin");
});

router.get("/first", ensureAuthenticated, (req, res) => {
  res.render("first");
});

router.get("/test", ensureAuthenticated, (req, res) => {
  res.render("test");
});

router.get("/sques", ensureAuthenticated, (req, res) => {
  db.query(
    "SELECT sel_crse_nme, sel_chptr_nme FROM add_ques",
    (err, results) => {
      if (err) {
        throw err;
      }
      res.render("sques", {
        user_data: results,
      });
    }
  );
});

router.get("/aques", ensureAuthenticated, (req, res) => {
  db.query("SELECT crse_nme FROM courses", (err, results) => {
    if (err) {
      throw err;
    }

    db.query("SELECT chptr_nme FROM courses", (err1, results1) => {
      if (err1) {
        throw err1;
      }
      res.render("aques", {
        user_data: results,
        userData: results1,
      });
    });
  });
});

router.post("/aques", (req, res) => {
  const {
    selCourseName,
    selChapterName,
    addQues,
    QuesMarks,
    opt1,
    opt2,
    opt3,
    opt4,
    Answer,
  } = req.body;

  const user = {
    sel_crse_nme: selCourseName,
    sel_chptr_nme: selChapterName,
    add_ques: addQues,
    marks: QuesMarks,
    opt_1: opt1,
    opt_2: opt2,
    opt_3: opt3,
    opt_4: opt4,
    ans: Answer,
  };

  let sql = "INSERT INTO add_ques SET ?";

  db.query(sql, user, (err, results) => {
    if (err) {
      throw err;
    }
    req.flash("success_msg", "your details submitted successfully");
    res.redirect("/users/sques");
  });
});

router.get("/course", ensureAuthenticated, (req, res) => {
  db.query("SELECT * FROM courses", (err, results) => {
    if (err) {
      throw err;
    }
    res.render("course", {
      user_data: results,
    });
  });
});

// route for update course data
router.post("/update1", (req, res) => {
  let sql =
    "UPDATE courses SET crse_nme='" +
    req.body.courseName +
    "',chptr_nme= '" +
    req.body.chapterName +
    "', crse_ques='" +
    req.body.totalQues +
    "', crse_marks= ' " +
    req.body.QuesMark +
    "' WHERE id=" +
    req.body.id;

  db.query(sql, (err, results) => {
    if (err) {
      throw err;
    }

    console.log(results);
    res.redirect("course");
  });
});

// delete courses details
router.post("/delete1", (req, res) => {
  const id = req.body.id;
  let sql = "DELETE FROM courses WHERE id=?";
  db.query(sql, id, (err, results) => {
    if (err) {
      throw err;
    }
    res.redirect("course");
  });
});

router.post("/test", ensureAuthenticated, (req, res) => {
  const { subject1, subject2, subject3, subject4, subject5, question } =
    req.body;

  const data = {
    ques_1: subject1,
    ques_2: subject2,
    ques_3: subject3,
    ques_4: subject4,
    ques_5: subject5,
    ques_6: question,
  };

  let sql = "INSERT INTO user_test SET ?";

  db.query(sql, data, (err, results) => {
    if (err) {
      throw err;
    }
    res.render("test", {
      message: "your details submitted successfully",
    });
  });
});

router.post("/first", (req, res) => {
  const { courseName, chapterName, totalQues, QuesMark } = req.body;

  const data = {
    crse_nme: courseName,
    chptr_nme: chapterName,
    crse_ques: totalQues,
    crse_marks: QuesMark,
  };

  let sql = "INSERT INTO courses SET ?";
  db.query(sql, data, (err, results) => {
    if (err) {
      throw err;
    }
    req.flash("success_msg", "your details submitted successfully");
    res.redirect("course");
  });
});

// logout handle
router.get("/logout", (req, res) => {
  req.logout();
  req.flash("success_msg", "you are logged out");
  res.redirect("/");
});

module.exports = router;
