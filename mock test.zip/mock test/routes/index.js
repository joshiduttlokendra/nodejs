const express = require("express");
const router = express.Router();
const db = require("../configure/config");
const passport = require("passport");

router.get("/", (req, res) => {
  res.render("login");
});

// login post handle
router.post("/", (req, res, next) => {
  console.log(req.body);

  passport.authenticate("local", {
    successRedirect: "/users/admin",
    failureRedirect: "/",
    failureFlash: true,
  })(req, res, next);
});

module.exports = router;
