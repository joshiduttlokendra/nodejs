const mysql = require("mysql");

//  create connetion
const db = mysql.createConnection({
  multipleStatements: true,
  host: "localhost",
  user: "root",
  password: "",
  database: "mock_test",
});

//   mysql connect
db.connect((err) => {
  if (err) {
    throw err;
  }
  console.log("mysql connected");
});

module.exports = db;
